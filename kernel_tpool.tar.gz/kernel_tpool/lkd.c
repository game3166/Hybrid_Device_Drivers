/* Using IOCTL on a char driver to create a new system call getprocinfo
//References:
//Char Driver :http://www.freesoftwaremagazine.com/articles/drivers_linux
//Ioctl: Linux Device Drivers, Edition 3.
//Ioctl: http://tuxthink.blogspot.com/2011/01/creating-ioctl-command.html
//Task Struct: http://www.spinics.net/lists/newbies/msg11186.html
//Start time: https://enc.com.au/2010/07/12/manually-calculating-process-times/
*/

#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h> 
#include <linux/slab.h> 
#include <linux/fs.h> 
#include <linux/errno.h> 
#include <linux/types.h> 
#include <linux/proc_fs.h>
#include <linux/fcntl.h> 
#include <asm-generic/uaccess.h>
#include <linux/sched.h>
#include <asm/current.h> 
#include <linux/list.h>
#include "lpc_ioctl.h"

//kthread functions
#include <linux/delay.h>
#include <linux/kthread.h>

#include "fifo.h"
#define NUM_THREADS 1

struct task_struct* current_task_struct; //task struct from sched.h
int major=60; //major number
char* buffer; //buffer to store a char for read and write


MODULE_AUTHOR("Chaitanya Soma"); 
MODULE_LICENSE("Dual BSD/GPL"); 
MODULE_DESCRIPTION("Local procedure calls between user and kernel");

//driver init functions
int driver_init(void);
void driver_exit(void);

//driver simulated functions - replace with actual device calls later
int char_open(struct inode *inode, struct file* file);
ssize_t my_read(struct file *file, char *buf, size_t count, loff_t *f_pos);
ssize_t my_write(struct file *file, char *buf, size_t count, loff_t *f_pos);
int char_release(struct inode *inode, struct file* file);


//ioctl functions for upcalls and downcalls
static long my_ioctl(struct file *file, unsigned int cmd, unsigned long arg);

//Module init and exit functions
module_init(driver_init);
module_exit(driver_exit);

//LPC Structures

//request queue
struct semaphore sem_req;
struct mutex dequeue_req;
struct mutex enqueue_req;
//wake up semaphore
struct semaphore wake[NUM_THREADS];

//consumer thread arguments
struct con_arg
{
	int tid;
	double stuff;
	struct node** head;
	struct node** tail;	
	
};

//producer thread arguments
struct prod_arg
{
	int tid;
	double stuff;
	struct node** head;
	struct node** tail;	
	
};


/*------------------------------------------------------------------------
 * Fops structure
 *------------------------------------------------------------------------
 */
struct file_operations fops = {
	open: char_open,
	read: my_read,
	write: my_write,  
	release: char_release,
	unlocked_ioctl: my_ioctl
};

//request queue

//Struct to store all function pointers

struct job procedures[10]; //array of job pointers to store all jobs

//function prototypes

void* consumer_thread(void* arg);
void task1(void* arg);
void task2(void* arg);
void task3(void);





/*------------------------------------------------------------------------
 * Function: driver_init()
 * Descrip : Module Init function, Registers the driver
 *------------------------------------------------------------------------
 */
int driver_init(void) 
{
	int result;
	//lpc vairable
	struct node* req_head;
	struct node* req_tail;
	
	//consumer threads
	static struct task_struct *con_threads[NUM_THREADS];//[NUM_THREADS];
	struct con_arg con_arg_list[NUM_THREADS];
	int done[NUM_THREADS];

	int i;//iterator
	

	req_head=NULL;
	req_tail=NULL;
	//intialize semaphore
	sema_init(&sem_req,0);
	mutex_init(&dequeue_req);
	mutex_init(&enqueue_req);


	//general variables
	
	//int rvalue;//return value

	//LPC END
	
	//Char Driver Registartaion
	//Major Number = 60
	//Driver Name = procinfo
	result = register_chrdev(major, "procinfo", &fops);
	if (result < 0) 
	{
		printk(KERN_INFO "Invalid major number %d\n", major);
		return result; //exit function
	}
	
	//to simulate a physical device we allocate one byte memory and read and write to that byte
	buffer=kmalloc(1,GFP_KERNEL);
	if(!buffer)
	{
		result=-ENOMEM; //out of memory error
		printk(KERN_INFO "Memory allocation failed, Unregistering Device procinfo\n");
		unregister_chrdev(major, "procinfo"); //unregister device
		return result;
	}
	//memory successfully allocated
	memset(buffer,0,1); //null memory
	printk(KERN_INFO "Module procinfo Inserted now and Driver Registered\n");

	//LPC Code starts

	//intitalize thread pool	
	for (i = 0; i < NUM_THREADS; i++)
	{
		done[i]=0; //not sure if we will need this
		con_arg_list[i].tid=i;
		con_arg_list[i].head=&req_head;
		con_arg_list[i].tail=&req_tail;
		con_threads[i]= kthread_create((int)consumer_thread,&con_arg_list[i],"thread1");	
		if(con_threads[i])
		{
			wake_up_process(con_threads[i]);
			printk(KERN_INFO "Thread Creation successfull \n");
		}
		else
		{
			printk(KERN_INFO "Thread Creation Failed \n");
		}
	

	}
	//Populate functio pointers
	procedures[0].procedure=(void*)task1;
	procedures[1].procedure=(void*)task2;
	procedures[2].procedure=(void*)task3;
	
	mdelay(1000);	
	printk(KERN_INFO "The END \n");
	return 0; //success
}

/*------------------------------------------------------------------------
 * Function: driver_exit()
 * Descrip : Module exit function, unregisters the driver and frees memory
 *------------------------------------------------------------------------
 */

void driver_exit(void) 
{
	unregister_chrdev(major, "procinfo"); //unregister device
	if(buffer!=NULL) //check if memory allocated
	{
		kfree(buffer);//free memory
	}
	printk(KERN_INFO "Removing Module and Unregistering procinfo\n");
}

/*------------------------------------------------------------------------
 * Function: char_open()
 * Descrip : Handles the open function for the driver
 *------------------------------------------------------------------------
 */
int char_open(struct inode *inode, struct file* file)
{
	return 0; //nothing to do, return success
}

/*------------------------------------------------------------------------
 * Function: my_read()
 * Descrip : Handles the open function, Read one byte from the buffer
 *------------------------------------------------------------------------
 */
ssize_t my_read(struct file *file, char *buf, size_t count, loff_t *f_pos)
{
	copy_to_user(buf,buffer,1); //copy one byte from user space into buffer
	if (*f_pos == 0) 
	{ 
		*f_pos+=1; 
		return 1; 
	} 
	else 
	{ 
		return 0; 
	}
}

/*------------------------------------------------------------------------
 * Function: my_write()
 * Descrip : Handles the write function, writes one byte to user buffer
 *------------------------------------------------------------------------
 */
ssize_t my_write(struct file *file, char *buf, size_t count, loff_t *f_pos)
{
	char *temp;
	temp=buf+count-1;
	copy_from_user(buffer,temp,1);//write to user buffer
	return 1;
}

/*------------------------------------------------------------------------
 * Function: char_release()
 * Descrip : Handles the release funciton
 *------------------------------------------------------------------------
 */
int char_release(struct inode *inode, struct file* file)
{
	return 0; //do nothing
}

/*------------------------------------------------------------------------
 * Function: my_ioctl()
 * Descrip : ioctl function provides syscall functionality
 *------------------------------------------------------------------------
 */

static long my_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{

	procinfo pinfo;		
	struct list_head * position;
	char* func_name;
	int index; 
//Function Pointer Stuff
	
	void* (*func_buff)(void* arg);
	void*  arg_buff;

	switch(cmd)
	{
		
		case PROC_INFO:
			if( copy_from_user( &pinfo, (procinfo*)arg, sizeof(procinfo)))
			{
				return -EACCES;
			}
			if(pinfo.pid == 0)
			{
				current_task_struct=get_current();
			}
			else
			{
				//current_task_struct=find_task_by_vpid(pinfo.pid);
				current_task_struct=pid_task (find_vpid(pinfo.pid),PIDTYPE_PID);
			}


			pinfo.pid=task_pid_nr(current_task_struct);
			pinfo.ppid=task_ppid_nr(current_task_struct);
			pinfo.start_time=current_task_struct->start_time;
			//pinfo.number= 55;
			pinfo.number=0;
			list_for_each(position, &current_task_struct->sibling)
			{
				pinfo.number++;
			}
			if( copy_to_user( (procinfo*)arg, &pinfo, sizeof(procinfo)))
			{
				return -EACCES;
			}
			break;

		case EXEC_LPC:
			
;	
			func_name=kmalloc(sizeof(char)*1000,GFP_KERNEL);
			printk(KERN_INFO "In execute routint\n");
			if( copy_from_user ( &index, (int*)arg, sizeof(int) ) )
			{
				printk(KERN_INFO "copy form user failed\n");
				return -EACCES;
			}
			func_buff=(void*)procedures[index].procedure;	
			//arg_buff=(void*) "abc";	
			func_buff(NULL);
			
			//schedule();
			printk(KERN_INFO "Arg Received is %d\n",index);		
			kfree(func_name);
			
			break;

		default:
			return -EINVAL;
	}
	return 0;
}


/*------------------------------------------------------------------------
 * Function: consumer_thread()
 * Descrip : Dequeus an element from the queue and executes the procedure
 *------------------------------------------------------------------------
 */
void* consumer_thread(void* arg)
{
	struct con_arg* args=(struct con_arg*)arg;
	
	void* (*func_buff)(void* arg);
	void*  arg_buff;
	//arg_buff=NULL;
	struct node* temp;
	printk(KERN_INFO "In consumer thread");
	return 0;
	/*while(1)
	{
		down(&sem_req);	
		//temp=dequeue(args->head,args->tail,args->tid,&dequeue_req);
		printk(KERN_INFO "Dequeue done from %d\r\n",temp->tid);
		func_buff=( temp->job ).procedure;
		arg_buff=(void*) (&(temp->tid));		
		printk(KERN_INFO "TID1 is %d, TID2 is %d\r\n",temp->tid,*(&(temp->tid)));
		func_buff(arg_buff);		
		printk(KERN_INFO "function executed tid %d\r\n",temp->tid);
		kfree(temp);
	*/
	

	//pthread_exit(NULL);
}

/*------------------------------------------------------------------------
 * Function: task1()
 * Descrip : Dummy task simulating exported functions
 *------------------------------------------------------------------------
 */
void task1(void* arg)
{	
	//char* message;	
	//tid=*((int*)(arg));
	//message=( (char*) (arg) );
	printk(KERN_INFO"Task 1:");// %s\n",message);	
}

/*------------------------------------------------------------------------
 * Function: task2()
 * Descrip : Dummy task simulating exported functions
 *------------------------------------------------------------------------
 */
void task2(void* arg)
{	
	//int tid;
	//tid=*((int*)(arg));
	printk(KERN_INFO"Task 2:");// %d\n",tid);
}
/*------------------------------------------------------------------------
 * Function: task2()
 * Descrip : Dummy task simulating exported functions
 *------------------------------------------------------------------------
 */
void task3(void)
{		
	printk(KERN_INFO"In Task 3\n");	
}
