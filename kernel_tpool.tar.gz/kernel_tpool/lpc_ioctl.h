#ifndef PROC_IOCTL_H
#define PROC_IOCTL_H
#include <linux/ioctl.h>


typedef struct 
{
	pid_t pid;
	pid_t ppid;
	unsigned long start_time;
	int number;
} procinfo;

#define PROC_INFO _IOWR('k', 1, procinfo*)
#define EXEC_LPC _IOWR('k', 2, int)

#endif
